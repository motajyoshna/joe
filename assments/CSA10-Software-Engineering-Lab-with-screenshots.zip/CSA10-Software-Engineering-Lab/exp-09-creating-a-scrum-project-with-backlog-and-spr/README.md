# Experiment 9: Creating a Scrum Project with Backlog and Sprint in Jira

**Course:** CSA10 – Software Engineering  |  **Tools:** Jira  |  **CO:** CO2

## Aim

Create a Scrum project, add and prioritize backlog items, create a 1-week sprint, start it and show the board at start and end.

## Procedure

1. Create Project → Scrum → `Scrum Workflow Project`, Team-managed.
2. Backlog items: Create User Registration Page, Develop API for Login, Design Home Page, Test Login Functionality, Deploy Application.
3. Prioritize by drag-and-drop (registration and login API on top).
4. Create Sprint, drag all five items in, set 1-week dates.
5. Start Sprint; screenshot the board (all in To Do).
6. Move tasks across To Do / In Progress / Done; screenshot the end board.

## Expected Output

- Scrum project with sprint board showing start and end states.

## Screenshots

Add your screenshots to a `screenshots/` folder here and link them:

```markdown
![Step output](screenshots/step1.png)
```

## Result

Scrum project created, sprint planned and started, progress tracked on the board.

## Viva Questions

**1. Sprint?**  
Ans: Fixed time-box (1–4 weeks) producing a usable increment.

**2. Product backlog?**  
Ans: Ordered list of all needed features and fixes.

**3. Story point?**  
Ans: Relative unit for effort/complexity.

**4. Burndown chart?**  
Ans: Remaining work versus time.

**5. Who prioritises the backlog?**  
Ans: Product Owner.

