# Experiment 11: Linking Jira Issues with Confluence for Progress Tracking

**Course:** CSA10 – Software Engineering  |  **Tools:** Jira & Confluence  |  **CO:** CO2

## Aim

Link Jira tasks of a Library Management System with a Confluence page using the Jira macro and a progress indicator.

## Procedure

1. Create Jira issues: Develop Book Search Functionality, Create User Login Page, Implement Book Borrowing Module, Design Admin Dashboard, Test Library Management System.
2. Set statuses (To Do / In Progress / Done); connect project to a Confluence space via Pages.
3. Confluence → Create → page `Library Management System Project Overview` with a short description.
4. Type `/jira`, insert issues; show Key, Summary, Assignee, Priority, Status.
5. Add a progress bar/status macro for completion; screenshot the page.

## Code / Commands

```text
JQL example:  project = LMS AND type = Task ORDER BY status
```

## Expected Output

- Confluence page with embedded Jira table and progress bar.

## Screenshots

Add your screenshots to a `screenshots/` folder here and link them:

```markdown
![Step output](screenshots/step1.png)
```

## Result

Jira tasks linked to Confluence with live status and progress tracking.

## Viva Questions

**1. What is Confluence?**  
Ans: Atlassian collaboration/documentation tool.

**2. Insert Jira issues?**  
Ans: `/jira` macro, then search or JQL.

**3. What is JQL?**  
Ans: Jira Query Language.

**4. Status auto-updates?**  
Ans: Yes, the macro shows live data.

**5. Why integrate?**  
Ans: Keeps documentation and work tracking connected.

