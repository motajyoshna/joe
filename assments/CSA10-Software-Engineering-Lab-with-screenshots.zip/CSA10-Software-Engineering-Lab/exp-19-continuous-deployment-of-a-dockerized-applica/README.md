# Experiment 19: Continuous Deployment of a Dockerized Application using GitHub Actions

**Course:** CSA10 – Software Engineering  |  **Tools:** GitHub Actions, Docker  |  **CO:** CO5

## Aim

Build and push a Docker image with GitHub Actions and deploy it to a cloud platform on every push.

## Procedure

1. Create repo `gha-docker-cd` with Flask app, requirements (flask, gunicorn), Dockerfile.
2. Create Docker Hub access token (Read & Write).
3. Add secrets: DOCKERHUB_USERNAME, DOCKERHUB_TOKEN and cloud credentials (AWS keys or RENDER_DEPLOY_HOOK).
4. Prepare cloud service (AWS ECS Fargate or Render).
5. Add `.github/workflows/cd.yml`; push to main.
6. Monitor in the Actions tab; verify Docker Hub tags and live URL.
7. Change message to Version 2, push, confirm automatic redeploy.

## Code / Commands

```text
# .github/workflows/cd.yml
name: CD - Build, Push and Deploy
on:
  push:
    branches: [ "main" ]
  workflow_dispatch:
env:
  IMAGE: ${{ secrets.DOCKERHUB_USERNAME }}/gha-docker-cd
jobs:
  build-push-deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: docker/login-action@v3
        with:
          username: ${{ secrets.DOCKERHUB_USERNAME }}
          password: ${{ secrets.DOCKERHUB_TOKEN }}
      - uses: docker/build-push-action@v6
        with:
          context: .
          push: true
          tags: |
            ${{ env.IMAGE }}:latest
            ${{ env.IMAGE }}:${{ github.sha }}
      # Option A: AWS ECS
      - uses: aws-actions/configure-aws-credentials@v4
        with:
          aws-access-key-id: ${{ secrets.AWS_ACCESS_KEY_ID }}
          aws-secret-access-key: ${{ secrets.AWS_SECRET_ACCESS_KEY }}
          aws-region: ap-south-1
      - run: aws ecs update-service --cluster gha-cluster --service gha-service --force-new-deployment
      # Option B (instead of A): Render
      # - run: curl -X POST "${{ secrets.RENDER_DEPLOY_HOOK }}"

# Dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
EXPOSE 5000
CMD ["gunicorn", "-b", "0.0.0.0:5000", "app:app"]
```

## Expected Output

- Green workflow run; Docker Hub tags `latest` and commit SHA; public URL shows the new version.

## Screenshots

Add your screenshots to a `screenshots/` folder here and link them:

```markdown
![Step output](screenshots/step1.png)
```

## Result

Continuous deployment implemented with GitHub Actions.

## Viva Questions

**1. Where are workflows stored?**  
Ans: `.github/workflows/`.

**2. Runner?**  
Ans: Machine that executes workflow jobs.

**3. Why secrets?**  
Ans: Keep credentials encrypted and out of code.

**4. actions/checkout?**  
Ans: Checks out repo code on the runner.

**5. Why tag with SHA?**  
Ans: Unique builds and easy rollback.

