# Experiment 12: Prioritizing Task Management System Requirements using MoSCoW and Kano in Jira

**Course:** CSA10 – Software Engineering  |  **Tools:** Jira  |  **CO:** CO2

## Aim

Create Task Management System requirements in Jira and prioritize them with MoSCoW and Kano labels.

## Procedure

1. Create Scrum project `Task Management System` (Team-managed).
2. Create four tasks in Backlog and add them to Sprint 1; Start Sprint (1 week).
3. Add MoSCoW labels and Kano labels to each task (see table).
4. Verify on the sprint board and capture screenshots (project, backlog, board, task details).

## Code / Commands

```text
| Requirement | MoSCoW | Kano |
|---|---|---|
| User Login and Role Assignment | Must | Basic |
| Task Creation and Assignment | Must | Basic |
| Task Prioritization and Deadlines | Should | Performance |
| Progress Tracking and Reporting | Could | Excitement |
```

## Expected Output

- Four tasks in Sprint 1 with both label sets.

## Screenshots

Add your screenshots to a `screenshots/` folder here and link them:

```markdown
![Step output](screenshots/step1.png)
```

## Result

Requirements created in Jira and prioritized with MoSCoW and Kano.

## Viva Questions

**1. Kano model?**  
Ans: Classifies features by effect on customer satisfaction.

**2. Basic feature example?**  
Ans: User login.

**3. Excitement feature example?**  
Ans: Smart reminders / automatic reports.

**4. Store MoSCoW in Jira?**  
Ans: Labels, Priority field or custom field.

**5. Why both models?**  
Ans: Business necessity (MoSCoW) plus satisfaction impact (Kano).

