# Experiment 14: Fork-and-Pull-Request Collaboration Workflow using Git and GitHub

**Course:** CSA10 – Software Engineering  |  **Tools:** Git / GitHub  |  **CO:** CO3

## Aim

Collaborate via fork → clone → branch → edit → commit → push → pull request.

## Procedure

1. Fork a public repo (e.g. `first-contributions`) with the Fork button.
2. Clone the fork and `cd` into it.
3. Create branch `update-readme`.
4. Edit README, then status/add/commit/push.
5. Open a pull request (compare & pull request) to the original main.
6. Review, respond to feedback with more commits (PR updates automatically).
7. Only maintainers of the original repo can merge; submit PR link.

## Code / Commands

```text
git clone https://github.com/<your-username>/first-contributions.git
cd first-contributions
git checkout -b update-readme
git branch
git status
git add README.md
git commit -m "Updated README for collaboration experiment"
git push -u origin update-readme
# after review feedback
git add .
git commit -m "Addressed review comments"
git push
```

## Expected Output

- PR link: https://github.com/firstcontributions/first-contributions/pull/122481

## Screenshots

Add your screenshots to a `screenshots/` folder here and link them:

```markdown
![Step output](screenshots/step1.png)
```

## Result

Fork-and-pull-request workflow demonstrated.

## Viva Questions

**1. Fork vs clone?**  
Ans: Fork = server-side copy on GitHub; clone = local copy.

**2. Pull request?**  
Ans: Proposal to merge changes with review.

**3. Why separate branch?**  
Ans: Keep main stable; isolate the feature.

**4. More commits to a PR branch?**  
Ans: PR updates automatically.

**5. Who merges?**  
Ans: Maintainers with write access.

