# Experiment 8: Cyclomatic Complexity of a Flow Graph

**Course:** CSA10 – Software Engineering  |  **Tools:** RAPTOR / calculator  |  **CO:** CO1

## Aim

Find the cyclomatic complexity of a flow graph with 17 edges, 13 nodes and 5 predicate nodes.

## Procedure

1. Note E = 17, N = 13, predicate nodes = 5.
2. Draw/label the control flow graph.
3. Apply `V(G) = E − N + 2 = 17 − 13 + 2 = 6`.
4. Verify `V(G) = P + 1 = 5 + 1 = 6`.
5. Interpret: six independent paths → at least six test cases.

## Code / Commands

```text
V(G) = E - N + 2P   (P = connected components)
V(G) = pi + 1       (pi = predicate nodes)

V(G)   Complexity   Risk
1-10   Simple       Low
11-20  Moderate     Moderate
21-50  Complex      High
>50    Untestable   Very high
```

## Expected Output

- Both methods give V(G) = 6.

## Screenshots

Implementation screenshots are listed below. Add your own tool screenshots to `screenshots/` too.

## Result

Cyclomatic complexity V(G) = 6 (moderate); six independent paths.

## Viva Questions

**1. Who introduced it?**  
Ans: Thomas J. McCabe, 1976.

**2. Predicate node?**  
Ans: A decision node with two or more outgoing edges.

**3. Basis path testing?**  
Ans: White-box technique covering every independent path once.

**4. What does V(G)=6 mean?**  
Ans: At least six test cases needed.

**5. Black- or white-box?**  
Ans: White-box.

## Implementation Screenshots

> Real terminal output captured from running these commands (see note under each).

**Cyclomatic complexity calculation**

![Cyclomatic complexity calculation](screenshots/8.png)

_Both formulas give 6._

