# Experiment 24: CI/CD Pipeline for a Flask Application using GitHub Actions with Cloud Deployment

**Course:** CSA10 – Software Engineering  |  **Tools:** GitHub Actions, Docker  |  **CO:** CO3

## Aim

Create a pipeline that tests, builds, pushes and deploys a Flask app (Heroku/AWS/Render).

## Procedure

1. Create repo `flask-cicd-actions` with app, tests, requirements, Dockerfile; run `pytest -q` locally.
2. Create cloud app (Heroku API key) and add secrets: DOCKERHUB_USERNAME, DOCKERHUB_TOKEN, HEROKU_API_KEY, HEROKU_APP_NAME.
3. Add `.github/workflows/ci-cd.yml` with jobs test → build-and-push → deploy.
4. Push to main; watch Actions; verify deployment and `/add/2/3` returns 5.
5. Break the add route to see test failure skip deployment; fix and re-run.

## Code / Commands

```text
# .github/workflows/ci-cd.yml
name: Flask CI/CD
on:
  push:
    branches: [ "main" ]
  pull_request:
    branches: [ "main" ]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.11"
      - run: pip install -r requirements.txt
      - run: pytest -v
  build-and-push:
    needs: test
    if: github.event_name == 'push'
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: docker/login-action@v3
        with:
          username: ${{ secrets.DOCKERHUB_USERNAME }}
          password: ${{ secrets.DOCKERHUB_TOKEN }}
      - uses: docker/build-push-action@v6
        with:
          context: .
          push: true
          tags: ${{ secrets.DOCKERHUB_USERNAME }}/flask-cicd:latest
  deploy:
    needs: build-and-push
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - env:
          HEROKU_API_KEY: ${{ secrets.HEROKU_API_KEY }}
        run: |
          heroku container:login
          heroku container:push web -a ${{ secrets.HEROKU_APP_NAME }}
          heroku container:release web -a ${{ secrets.HEROKU_APP_NAME }}

# test_app.py
from app import app
client = app.test_client()
def test_home():
    r = client.get("/")
    assert r.status_code == 200
    assert r.get_json()["status"] == "running"
def test_add():
    assert client.get("/add/2/3").get_json()["result"] == 5

# Dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
ENV PORT=5000
EXPOSE 5000
CMD gunicorn -b 0.0.0.0:$PORT app:app
```

## Expected Output

- Jobs test → build-and-push → deploy succeed; pytest: 2 passed; app live at the cloud URL.

## Screenshots

Implementation screenshots are listed below. Add your own tool screenshots to `screenshots/` too.

## Result

CI/CD pipeline tests, builds, pushes and deploys the Flask app automatically.

## Viva Questions

**1. `needs` keyword?**  
Ans: Makes a job wait for another job to succeed.

**2. Why test before build?**  
Ans: Prevent broken code from being packaged/deployed.

**3. How does Heroku set the port?**  
Ans: Via the PORT environment variable.

**4. pytest?**  
Ans: Python testing framework.

**5. What triggers it?**  
Ans: Push or pull request to main.

## Implementation Screenshots

> Real terminal output captured from running these commands (see note under each).

**Exp 24 - Test job (pytest: 2 passed)**

![Exp 24 - Test job (pytest: 2 passed)](screenshots/pytest_run.png)

_The test job's command run locally. GitHub Actions, Docker Hub and cloud deploy were not run here._

