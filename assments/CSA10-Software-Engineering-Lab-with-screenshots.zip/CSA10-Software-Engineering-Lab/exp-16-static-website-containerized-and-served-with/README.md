# Experiment 16: Static Website Containerized and Served with Docker and Nginx

**Course:** CSA10 – Software Engineering  |  **Tools:** Docker  |  **CO:** CO3

## Aim

Create a static site, serve it with Nginx in a Docker container and access it in a browser.

## Procedure

1. Verify Docker: `docker --version`, `docker run hello-world`.
2. Create folder `static-site` with `index.html`, `style.css`, `Dockerfile`.
3. Build `docker build -t static-site:1.0 .`.
4. Run `docker run -d --name mysite -p 8080:80 static-site:1.0`.
5. Open http://localhost:8080.
6. Clean up with `docker stop mysite && docker rm mysite`.

## Code / Commands

```text
# Dockerfile
FROM nginx:alpine
RUN rm -rf /usr/share/nginx/html/*
COPY index.html style.css /usr/share/nginx/html/
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]

# index.html (minimal)
<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><title>My Static Website</title><link rel="stylesheet" href="style.css"></head>
<body><header><h1>Welcome to My Static Website</h1></header>
<main><p>This page is served by an Nginx container built with Docker.</p></main></body></html>

# style.css
body { font-family: Arial, sans-serif; margin: 0; background: #f4f6f9; }
header { background: #1f3864; color: #fff; padding: 20px; text-align: center; }
```

## Expected Output

- `docker ps` shows `0.0.0.0:8080->80/tcp`; page displays at http://localhost:8080.

## Screenshots

Add your screenshots to a `screenshots/` folder here and link them:

```markdown
![Step output](screenshots/step1.png)
```

## Result

Static website containerized with Nginx and accessed successfully.

## Viva Questions

**1. Image vs container?**  
Ans: Image = read-only template; container = running instance.

**2. EXPOSE?**  
Ans: Documents the listening port; publish with -p.

**3. -d flag?**  
Ans: Detached/background mode.

**4. Nginx web root?**  
Ans: /usr/share/nginx/html.

**5. Why alpine?**  
Ans: Very small, secure base image.

