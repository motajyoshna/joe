# Experiment 17: Flask API Containerized with Docker, Pushed to Docker Hub and Deployed on Kubernetes

**Course:** CSA10 – Software Engineering  |  **Tools:** Docker & Kubernetes  |  **CO:** CO3

## Aim

Containerize a Flask API, push to Docker Hub and deploy with Deployment + NodePort Service.

## Procedure

1. Create `app.py`, `requirements.txt`, `Dockerfile`.
2. Build, test locally, `docker login`, push to Docker Hub.
3. Start cluster (`minikube start` or Docker Desktop K8s); `kubectl get nodes`.
4. Create `deployment.yaml` (2 replicas) and `service.yaml` (NodePort 30007).
5. `kubectl apply -f` both, verify pods and service.
6. Access http://localhost:30007 (or `minikube service flask-api-service --url`).

## Code / Commands

```text
# app.py
from flask import Flask, jsonify, request
app = Flask(__name__)
students = [{"id": 1, "name": "Arun", "dept": "CSE"}, {"id": 2, "name": "Divya", "dept": "IT"}]

@app.route("/")
def home():
    return jsonify(message="Hello from Flask API on Kubernetes")

@app.route("/api/students", methods=["GET"])
def get_students():
    return jsonify(students)

@app.route("/api/students", methods=["POST"])
def add_student():
    data = request.get_json()
    data["id"] = len(students) + 1
    students.append(data)
    return jsonify(data), 201

@app.route("/health")
def health():
    return jsonify(status="UP")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

# requirements.txt
flask==3.0.3

# Dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY app.py .
EXPOSE 5000
CMD ["python", "app.py"]

# Commands
docker build -t <dockerhub-username>/flask-api:1.0 .
docker push <dockerhub-username>/flask-api:1.0
kubectl apply -f deployment.yaml
kubectl apply -f service.yaml
kubectl get pods -o wide
kubectl get svc

# deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: flask-api-deployment
spec:
  replicas: 2
  selector:
    matchLabels:
      app: flask-api
  template:
    metadata:
      labels:
        app: flask-api
    spec:
      containers:
      - name: flask-api
        image: <dockerhub-username>/flask-api:1.0
        ports:
        - containerPort: 5000

# service.yaml
apiVersion: v1
kind: Service
metadata:
  name: flask-api-service
spec:
  type: NodePort
  selector:
    app: flask-api
  ports:
  - port: 5000
    targetPort: 5000
    nodePort: 30007
```

## Expected Output

- 2 pods Running; service `5000:30007/TCP`; `/` and `/api/students` return JSON.

## Screenshots

Implementation screenshots are listed below. Add your own tool screenshots to `screenshots/` too.

## Result

Flask API containerized, pushed and deployed on Kubernetes; accessed via NodePort.

## Viva Questions

**1. Pod?**  
Ans: Smallest deployable unit wrapping containers.

**2. NodePort range?**  
Ans: 30000–32767.

**3. Service selector?**  
Ans: Chooses pods by label.

**4. Why 0.0.0.0?**  
Ans: To accept connections from outside the container.

**5. kubectl apply -f?**  
Ans: Creates/updates resources from a manifest.

## Implementation Screenshots

> Real terminal output captured from running these commands (see note under each).

**Exp 17 - Flask API running locally**

![Exp 17 - Flask API running locally](screenshots/local_run.png)

_Flask API tested locally with curl (before containerizing). Docker push and Kubernetes steps were not run here._

