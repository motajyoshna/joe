# Experiment 25: Creating a GitHub Repository and Pushing a README File

**Course:** CSA10 – Software Engineering  |  **Tools:** Git / GitHub  |  **CO:** CO3

## Aim

Create a repo, clone it, edit README.md, then commit and push.

## Procedure

1. New repository with README enabled.
2. Clone via HTTPS.
3. Edit README.md in VS Code with a project description.
4. `git status`, `git add`, `git commit`, `git push origin main`.
5. Refresh GitHub to verify.

## Code / Commands

```text
git clone https://github.com/username/My-Personal-Project.git
cd My-Personal-Project
code .
git status
git add README.md
git commit -m "Updated README with project description"
git push origin main
```

## Expected Output

- `1 file changed`; push shows `main -> main`; updated README visible on GitHub.

## Screenshots

Implementation screenshots are listed below. Add your own tool screenshots to `screenshots/` too.

## Result

Repository created, README updated, changes pushed.

## Viva Questions

**1. Staging area?**  
Ans: Where changes are prepared before commit.

**2. origin?**  
Ans: Default name of the remote.

**3. Markdown?**  
Ans: Lightweight markup used for READMEs.

**4. Git vs GitHub?**  
Ans: Version control tool vs hosting service.

**5. See history?**  
Ans: `git log` / `git log --oneline`.

## Implementation Screenshots

> Real terminal output captured from running these commands (see note under each).

**Clone, edit, commit and push README**

![Clone, edit, commit and push README](screenshots/git_run.png)

_Captured locally; the GitHub remote is simulated with a local bare repository (same git commands)._

