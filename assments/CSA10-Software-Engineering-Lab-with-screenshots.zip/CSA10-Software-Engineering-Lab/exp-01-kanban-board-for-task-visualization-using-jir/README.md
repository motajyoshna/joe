# Experiment 1: Kanban Board for Task Visualization using Jira

**Course:** CSA10 – Software Engineering  |  **Tools:** Jira / Trello  |  **CO:** CO1

## Aim

Create a Kanban board in Jira with To Do, In Progress and Done columns, add at least five tasks and move them across columns to simulate a workflow.

## Procedure

1. Log in at https://id.atlassian.com/login.
2. Create Project → Kanban template → name `Task Management Board`, Team-managed, Open access.
3. Review default work types and statuses (To Do, In Progress, In Review, Done); keep sample work items disabled.
4. In Backlog, create: Restaurant Listing, Add Food to Cart, User Registration, Payment Integration, Design Login Page (plus optional Collect Project Requirements, Design UI Mockups).
5. Place the five tasks in the To Do column of the board.
6. Drag: User Registration → In Progress; Design Login Page → In Review; Payment Integration → Done.
7. Final: Design Login Page → Done; User Registration stays In Progress; Restaurant Listing and Add Food to Cart stay in To Do.

## Expected Output

- Kanban project `Task Management Board` created.
- Five or more tasks visible and moved across To Do → In Progress → In Review → Done.

## Screenshots

Add your screenshots to a `screenshots/` folder here and link them:

```markdown
![Step output](screenshots/step1.png)
```

## Result

Kanban board created in Jira, tasks added and moved across columns; workflow simulated successfully.

## Viva Questions

**1. What is Kanban?**  
Ans: A visual workflow method using boards, columns and cards to show work status and limit WIP.

**2. What is a WIP limit?**  
Ans: Max items allowed in a column at once; prevents multitasking and exposes bottlenecks.

**3. Kanban vs Scrum?**  
Ans: Kanban has continuous flow, no sprints; Scrum has time-boxed sprints and defined roles.

**4. Lead time vs cycle time?**  
Ans: Lead time = request to delivery; cycle time = start of work to completion.

**5. Two Jira Kanban reports?**  
Ans: Cumulative Flow Diagram and Control Chart.

