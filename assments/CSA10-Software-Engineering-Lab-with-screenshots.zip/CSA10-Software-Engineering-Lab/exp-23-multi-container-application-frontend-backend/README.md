# Experiment 23: Multi-Container Application (Frontend, Backend, Database) on Kubernetes with Scaling

**Course:** CSA10 – Software Engineering  |  **Tools:** Docker, Kubernetes  |  **CO:** CO3

## Aim

Deploy Nginx frontend + Flask backend + MySQL on Kubernetes, monitor, and scale the frontend.

## Procedure

1. `minikube start`, enable metrics-server, create namespace `multiapp`.
2. Build and push backend and frontend images.
3. Apply `mysql.yaml` (Secret, ConfigMap, PVC, Deployment, Service), `backend.yaml`, `frontend.yaml`.
4. Monitor: `kubectl get all`, `describe`, `logs`, `minikube dashboard`.
5. Open frontend via NodePort 30080.
6. Scale: `kubectl scale deployment frontend --replicas=4`; optional HPA.

## Code / Commands

```text
minikube start --cpus=2 --memory=4096
minikube addons enable metrics-server
kubectl create namespace multiapp
kubectl config set-context --current --namespace=multiapp

docker build -t <dockerhub-username>/k8s-backend:1.0 backend
docker build -t <dockerhub-username>/k8s-frontend:1.0 frontend
docker push <dockerhub-username>/k8s-backend:1.0
docker push <dockerhub-username>/k8s-frontend:1.0

kubectl apply -f mysql.yaml
kubectl apply -f backend.yaml
kubectl apply -f frontend.yaml
kubectl get all
minikube service frontend-service -n multiapp --url
kubectl scale deployment frontend --replicas=4
kubectl get pods -l app=frontend
kubectl autoscale deployment frontend --cpu-percent=50 --min=2 --max=6
kubectl get hpa

# Architecture
Browser -> frontend (Nginx, NodePort 30080) -> backend (Flask, ClusterIP 5000) -> mysql (ClusterIP 3306)

# backend/app.py
from flask import Flask, jsonify
import os, mysql.connector
app = Flask(__name__)
def db():
    return mysql.connector.connect(host=os.environ["DB_HOST"], user="root", password=os.environ["DB_PASSWORD"], database="college")
@app.route("/api/students")
def students():
    con = db(); cur = con.cursor(dictionary=True)
    cur.execute("SELECT id, name, dept FROM students")
    rows = cur.fetchall(); con.close()
    return jsonify(rows)
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

# backend/Dockerfile
FROM python:3.11-slim
WORKDIR /app
RUN pip install flask mysql-connector-python
COPY app.py .
CMD ["python", "app.py"]

# frontend/default.conf
server {
  listen 80;
  location / { root /usr/share/nginx/html; index index.html; }
  location /api/ { proxy_pass http://backend-service:5000; }
}

# frontend/Dockerfile
FROM nginx:alpine
COPY default.conf /etc/nginx/conf.d/default.conf
COPY index.html /usr/share/nginx/html/index.html

# mysql.yaml (abridged: Secret, ConfigMap init.sql, PVC 1Gi, Deployment mysql:8.0, Service 3306)
# backend.yaml  (Deployment x2, env DB_HOST=mysql-service, DB_PASSWORD from secret; ClusterIP Service 5000)
# frontend.yaml (Deployment x2, cpu requests 50m / limits 200m; NodePort Service 30080)
# NOTE: the demo password in the Secret is for lab use only.
```

## Expected Output

- All deployments Running; frontend shows student list from MySQL; four frontend pods after scaling.

## Screenshots

Add your screenshots to a `screenshots/` folder here and link them:

```markdown
![Step output](screenshots/step1.png)
```

## Result

Multi-container app deployed, monitored and scaled on Kubernetes.

## Viva Questions

**1. How do tiers find each other?**  
Ans: Services and cluster DNS names.

**2. Secret?**  
Ans: Object storing sensitive data (base64-encoded).

**3. PVC?**  
Ans: Storage request that survives pod restarts.

**4. Manual scaling vs HPA?**  
Ans: `kubectl scale` vs automatic by CPU/metrics.

**5. Service type for database?**  
Ans: ClusterIP.

