# Experiment 30: Forking, Feature Branch and Pull Request to the Original Repository

**Course:** CSA10 – Software Engineering  |  **Tools:** Git / GitHub  |  **CO:** CO4

## Aim

Fork a repo, work on a feature branch and open a PR to the original repository.

## Procedure

1. Fork the original repo to your account.
2. Clone the fork; `git checkout -b feature-update`.
3. Implement the change without touching unrelated code.
4. `git status`, `git add .`, `git commit -m "Added new feature"`, `git push -u origin feature-update`.
5. Open PR: base = original repo main, compare = your fork's feature-update.
6. Verify the PR and submit for review.

## Code / Commands

```text
git clone <forked_repository_url>
cd <repository_name>
git checkout -b feature-update
git add .
git commit -m "Added new feature"
git push -u origin feature-update

# keep fork in sync
git remote add upstream <original-url>
git fetch upstream
git merge upstream/main
```

## Expected Output

- PR from fork's `feature-update` to original `main` opened.

## Screenshots

Implementation screenshots are listed below. Add your own tool screenshots to `screenshots/` too.

## Result

Fork-based feature contribution submitted as a pull request.

## Viva Questions

**1. upstream?**  
Ans: The original repository a fork came from.

**2. Sync a fork?**  
Ans: `git fetch upstream` + `git merge upstream/main`.

**3. Push to original directly?**  
Ans: Not without write access; use a PR.

**4. Why a new branch?**  
Ans: Existing main code stays unaffected.

**5. Files changed tab?**  
Ans: Line-by-line diff of modified files.

## Implementation Screenshots

> Real terminal output captured from running these commands (see note under each).

**Fork clone, feature branch, push and upstream remote**

![Fork clone, feature branch, push and upstream remote](screenshots/git_run.png)

_The Fork button and Create pull request are GitHub UI steps and aren't shown. Captured locally; the GitHub remote is simulated with a local bare repository (same git commands)._

