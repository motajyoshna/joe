# Experiment 10: MoSCoW Prioritization of Library Management System Requirements

**Course:** CSA10 – Software Engineering  |  **Tools:** Google Sheets / Excel  |  **CO:** CO2

## Aim

Categorize Library Management System requirements using MoSCoW with justification based on impact and feasibility.

## Procedure

1. Create sheet `Library Management System – MoSCoW Prioritization`.
2. Columns: Requirement ID, Requirement Description, MoSCoW Category, Justification.
3. Enter the ten requirements, assign one category each and justify.
4. Format headings, colour-code categories, save.

## Code / Commands

```text
| ID | Requirement | MoSCoW | Justification |
|----|-------------|--------|---------------|
| R1 | Search books by title/author | Must | Core function used by every user |
| R2 | Online book reservation | Must | Key service, reduces visits |
| R3 | Monthly borrowed-book reports | Should | Needed for management; can follow core release |
| R4 | Email for overdue books | Should | Improves returns; low effort |
| R5 | QR code borrow/return | Could | Speeds circulation, needs hardware |
| R6 | Librarian dashboard | Must | Daily operations |
| R7 | Review and rate books | Could | Engagement, not essential |
| R8 | Chatbot | Won't | High cost, low immediate value |
| R9 | Mobile app | Won't | Large effort; web is sufficient now |
| R10 | Multi-language support | Could | Helpful, moderate effort |
```

## Expected Output

- Spreadsheet with all ten requirements categorized and justified.

## Screenshots

Add your screenshots to a `screenshots/` folder here and link them:

```markdown
![Step output](screenshots/step1.png)
```

## Result

Requirements prioritized with MoSCoW and submitted as a spreadsheet.

## Viva Questions

**1. Expand MoSCoW.**  
Ans: Must, Should, Could, Won't have (this time).

**2. Why lowercase o's?**  
Ans: Only to make the acronym pronounceable.

**3. Criteria used?**  
Ans: Impact on users/stakeholders and feasibility (time, budget, resources).

**4. Two other techniques?**  
Ans: Kano model, 100-point method, AHP.

**5. Won't Have?**  
Ans: Out of scope for the current release.

