# Experiment 20: Team Project Repository with Branches, Pull Requests and README Documentation

**Course:** CSA10 – Software Engineering  |  **Tools:** Git / GitHub  |  **CO:** CO3

## Aim

Set up a team repo, develop modules on branches, merge via reviewed PRs, resolve conflicts and document the workflow.

## Procedure

1. Team lead creates `team-project` (Public, with README); add collaborators; optional branch protection (1 approval).
2. Members clone the repo.
3. Each creates a module branch: feature-login, feature-catalog, feature-cart.
4. Develop, commit and push each module.
5. Open PRs to main, assign reviewers, approve and merge.
6. Create/resolve a README.md conflict locally, push, merge.
7. Document workflow in README via a docs-branch PR; submit repo URL.

## Code / Commands

```text
git clone https://github.com/<team-lead>/team-project.git
cd team-project
git checkout -b feature-login
git add login.py
git commit -m "Add login module"
git push -u origin feature-login

# resolve conflict
git checkout feature-cart
git pull origin main
# edit README.md, remove markers
git add README.md
git commit -m "Resolve README merge conflict"
git push

# login.py
def login(username, password):
    users = {"admin": "admin123", "student": "pass123"}
    if users.get(username) == password:
        return "Login successful"
    return "Invalid credentials"
```

## Expected Output

- Branches main, feature-login, feature-catalog, feature-cart; PRs reviewed and merged; README documents workflow.

## Screenshots

Add your screenshots to a `screenshots/` folder here and link them:

```markdown
![Step output](screenshots/step1.png)
```

## Result

Team repository set up with branches, reviewed PRs, conflict resolution and README.

## Viva Questions

**1. Branch protection?**  
Ans: Rule blocking direct pushes; requires reviewed PRs/checks.

**2. Squash and merge?**  
Ans: Combines PR commits into one.

**3. Add collaborators?**  
Ans: Settings → Collaborators → Add people.

**4. Why document workflow?**  
Ans: So everyone follows the same process.

**5. Code review?**  
Ans: Peer examination of changes before merging.

