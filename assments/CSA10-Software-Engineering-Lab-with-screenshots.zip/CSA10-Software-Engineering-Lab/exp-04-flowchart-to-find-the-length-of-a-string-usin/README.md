# Experiment 4: Flowchart to Find the Length of a String using RAPTOR

**Course:** CSA10 – Software Engineering  |  **Tools:** RAPTOR  |  **CO:** CO1

## Aim

Draw and run a RAPTOR flowchart that reads a string and displays its number of characters.

## Procedure

1. File → New in RAPTOR.
2. Input symbol: prompt `Enter a String:` into `str`.
3. Assignment symbol: `length ← Length_Of(str)`.
4. Output symbol: `Total Number of Characters =` and `length`.
5. Connect Start → Input → Assignment → Output → End; click Run.

## Code / Commands

```text
Algorithm:
1. Start
2. Read str
3. length <- Length_Of(str)
4. Display length
5. Stop
```

## Expected Output

- Input: `SoftwareEngineering`
- Output: `Total Number of Characters = 19`

## Screenshots

Implementation screenshots are listed below. Add your own tool screenshots to `screenshots/` too.

## Result

Flowchart drawn, executed and verified in RAPTOR.

## Viva Questions

**1. What is RAPTOR?**  
Ans: A flowchart-based visual programming tool.

**2. Function for string length?**  
Ans: Length_Of().

**3. Immutable string?**  
Ans: Contents cannot change; any change creates a new string.

**4. Six basic symbols?**  
Ans: Assignment, Call, Input, Output, Selection, Loop.

**5. How to execute?**  
Ans: Run (Execute to Completion) or step-by-step.

## Implementation Screenshots

> Real terminal output captured from running these commands (see note under each).

**String length output**

![String length output](screenshots/4.png)

_Python equivalent of the RAPTOR flowchart logic (not the RAPTOR GUI). Output matches expected 19._

