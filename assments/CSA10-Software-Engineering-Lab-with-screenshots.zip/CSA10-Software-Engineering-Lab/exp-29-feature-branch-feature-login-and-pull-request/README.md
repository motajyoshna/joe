# Experiment 29: Feature Branch (feature-login) and Pull Request

**Course:** CSA10 – Software Engineering  |  **Tools:** Git / GitHub  |  **CO:** CO4

## Aim

Create `feature-login`, add `login.py`, push and merge via a pull request.

## Procedure

1. Open local repo and check status.
2. `git checkout -b feature-login`.
3. Create `login.py`; commit and `git push -u origin feature-login`.
4. Open PR (base main, compare feature-login) titled `Add Login Function`; review and merge.
5. `git checkout main && git pull origin main`; confirm `login.py` exists.

## Code / Commands

```text
git checkout -b feature-login
git add login.py
git commit -m "Added login function"
git push -u origin feature-login
git checkout main
git pull origin main
ls

# login.py
def login(username, password):
    if username == "admin" and password == "1234":
        return "Login successful"
    else:
        return "Invalid username or password"
```

## Expected Output

- PR `Add Login Function` merged; `login.py` present on main.

## Screenshots

Implementation screenshots are listed below. Add your own tool screenshots to `screenshots/` too.

## Result

Feature branch implemented and merged through a pull request.

## Viva Questions

**1. `git checkout -b`?**  
Ans: Creates and switches to a new branch.

**2. `-u` in push?**  
Ans: Sets upstream tracking branch.

**3. Delete branch locally?**  
Ans: `git branch -d feature-login`.

**4. `git switch`?**  
Ans: Newer command to change branches (`-c` creates).

**5. Why merge via PR?**  
Ans: Enables review and checks before reaching main.

## Implementation Screenshots

> Real terminal output captured from running these commands (see note under each).

**Feature branch, push and merge into main**

![Feature branch, push and merge into main](screenshots/git_run.png)

_The PR page/merge button is a GitHub UI step; here the merge is simulated locally. Captured locally; the GitHub remote is simulated with a local bare repository (same git commands)._

