# Experiment 15: Working with Git Branches and Resolving Merge Conflicts

**Course:** CSA10 – Software Engineering  |  **Tools:** Git / GitHub  |  **CO:** CO3

## Aim

Merge main into a feature branch, resolve conflicts manually, push and open a PR.

## Procedure

1. Clone the shared repo; create `feature-update`; edit README; commit and push.
2. Switch to main and `git pull origin main`.
3. Back on the feature branch run `git merge main`.
4. On conflict, open the file, keep correct content, remove markers.
5. `git add` the file, commit, push, and create PR feature-update → main.

## Code / Commands

```text
git clone <repository_url>
cd <repository_name>
git checkout -b feature-update
git add README.md
git commit -m "Updated README"
git push -u origin feature-update
git checkout main
git pull origin main
git checkout feature-update
git merge main
# resolve conflict markers, then:
git add <conflicted_file>
git commit -m "Resolved merge conflict"
git push origin feature-update

# Conflict markers
<<<<<<< HEAD
your feature branch changes
=======
changes from main
>>>>>>> main
```

## Expected Output

- `CONFLICT (content): Merge conflict in README.md`, then resolved and pushed.

## Screenshots

Implementation screenshots are listed below. Add your own tool screenshots to `screenshots/` too.

## Result

Conflict resolved manually and merged branch pushed with a PR.

## Viva Questions

**1. When does a conflict occur?**  
Ans: Same part of a file changed differently in both branches.

**2. What do the markers mean?**  
Ans: Start of current change, separator, end of incoming change.

**3. Abort a merge?**  
Ans: `git merge --abort`.

**4. fetch vs pull?**  
Ans: fetch downloads only; pull = fetch + merge.

**5. Fast-forward?**  
Ans: Branch pointer just moves ahead; no divergent commits.

## Implementation Screenshots

> Real terminal output captured from running these commands (see note under each).

**Conflict, manual resolution and merge commit**

![Conflict, manual resolution and merge commit](screenshots/conflict_resolution.png)

_Captured locally; the GitHub remote is simulated with a local bare repository (same git commands)._

