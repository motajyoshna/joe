# Experiment 18: CI/CD Pipeline with Jenkins for a Containerized Application

**Course:** CSA10 – Software Engineering  |  **Tools:** Jenkins, Docker  |  **CO:** CO4

## Aim

Set up Jenkins and a pipeline that builds, tests and deploys a containerized Flask app on every push.

## Procedure

1. Run Jenkins LTS in Docker with the Docker socket mounted; install Docker CLI inside.
2. Unlock with initial admin password; install suggested plugins (Git, Pipeline, Docker Pipeline).
3. Create GitHub repo `jenkins-flask-demo` with app, test, requirements, Dockerfile, Jenkinsfile.
4. Jenkins: New Item → Pipeline → Pipeline script from SCM → repo URL, `*/main`, `Jenkinsfile`.
5. Build Now; check Stage View; open http://localhost:5000.
6. Push a change; pollSCM triggers a new build.

## Code / Commands

```text
docker volume create jenkins_home
docker run -d --name jenkins -p 8080:8080 -p 50000:50000 \
  -v jenkins_home:/var/jenkins_home \
  -v /var/run/docker.sock:/var/run/docker.sock \
  jenkins/jenkins:lts
docker exec -u root jenkins bash -c "apt-get update && apt-get install -y docker.io"
docker exec -u root jenkins chmod 666 /var/run/docker.sock
docker exec jenkins cat /var/jenkins_home/secrets/initialAdminPassword

// Jenkinsfile
pipeline {
  agent any
  environment { IMAGE = "flask-cicd"; TAG = "${env.BUILD_NUMBER}" }
  triggers { pollSCM('H/2 * * * *') }
  stages {
    stage('Checkout') { steps { git branch: 'main', url: 'https://github.com/<username>/jenkins-flask-demo.git' } }
    stage('Build Image') { steps { sh 'docker build -t $IMAGE:$TAG .' } }
    stage('Test') { steps { sh 'docker run --rm $IMAGE:$TAG pytest -q' } }
    stage('Deploy') {
      steps {
        sh 'docker rm -f flask-app || true'
        sh 'docker run -d --name flask-app -p 5000:5000 $IMAGE:$TAG'
      }
    }
  }
  post {
    success { echo 'Pipeline completed: application deployed on port 5000' }
    failure { echo 'Pipeline failed - check the console output' }
  }
}

# test_app.py
from app import app
def test_home():
    resp = app.test_client().get("/")
    assert resp.status_code == 200
    assert b"Jenkins" in resp.data
```

## Expected Output

- Stage View: Checkout → Build Image → Test → Deploy all green; app live on port 5000.

## Screenshots

Implementation screenshots are listed below. Add your own tool screenshots to `screenshots/` too.

## Result

Jenkins CI/CD pipeline builds, tests and deploys the containerized app automatically.

## Viva Questions

**1. CI?**  
Ans: Automatically building/testing code on each commit.

**2. Jenkinsfile?**  
Ans: Pipeline-as-code file stored with the source.

**3. Delivery vs Deployment?**  
Ans: Delivery needs manual approval; Deployment is automatic.

**4. Trigger on push?**  
Ans: GitHub webhook or pollSCM.

**5. Default Jenkins port?**  
Ans: 8080.

## Implementation Screenshots

> Real terminal output captured from running these commands (see note under each).

**Exp 18 - Test stage (pytest)**

![Exp 18 - Test stage (pytest)](screenshots/pytest_run.png)

_The Test stage command run locally. The Jenkins server and pipeline were not run here._

