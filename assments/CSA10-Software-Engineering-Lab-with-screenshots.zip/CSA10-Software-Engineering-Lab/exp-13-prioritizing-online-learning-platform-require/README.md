# Experiment 13: Prioritizing Online Learning Platform Requirements using MoSCoW and Kano in Jira

**Course:** CSA10 – Software Engineering  |  **Tools:** Jira  |  **CO:** CO2

## Aim

Categorize Online Learning Platform requirements in Jira with MoSCoW and Kano.

## Procedure

1. Create Scrum project `Online Learning Platform` (Team-managed).
2. Create six tasks and drag them into Sprint 1; Start Sprint (1 week).
3. Add MoSCoW and Kano labels per the table.
4. Verify labels on the sprint board.

## Code / Commands

```text
| Requirement | MoSCoW | Kano |
|---|---|---|
| Course Enrollment and Registration | Must | Basic |
| Video Lecture Streaming | Must | Performance |
| Interactive Quizzes and Assignments | Should | Performance |
| Progress Tracking Dashboard | Should | Performance |
| Peer-to-Peer Discussion Forums | Could | Excitement |
| Certificate Generation | Could | Excitement |
```

## Expected Output

- Six labelled tasks on the sprint board.

## Screenshots

Add your screenshots to a `screenshots/` folder here and link them:

```markdown
![Step output](screenshots/step1.png)
```

## Result

Learning platform requirements categorized and prioritized in Jira.

## Viva Questions

**1. Why is enrolment Basic?**  
Ans: Users expect it; platform unusable without it.

**2. Why is certificate Excitement?**  
Ans: Delights but absence doesn't block learning.

**3. Performance feature?**  
Ans: Better implementation = proportionally higher satisfaction.

**4. Filter by label?**  
Ans: JQL: `labels = Kano-Basic`.

**5. Do Kano categories change?**  
Ans: Yes, excitement features drift toward basic over time.

