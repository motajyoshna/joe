# Experiment 2: Prototype of a Bus Ticket Booking System using Figma

**Course:** CSA10 – Software Engineering  |  **Tools:** Figma  |  **CO:** CO1

## Aim

Build a simple clickable prototype (Login and Home/Search screens) of a Bus Ticket Booking System in Figma.

## Procedure

1. Sign in at https://www.figma.com → New Design File.
2. Select Frame tool (F) → Desktop (1440 x 1024).
3. Login screen: title `Bus Ticket Booking`, Username and Password fields, Login button.
4. Duplicate the frame for the Home screen: From, To, Travel Date, Search Buses button.
5. Switch to Prototype mode and connect Login → Home Screen (On Click → Navigate to).
6. Click Present (▶) and test the flow.

## Expected Output

- Login screen and Home screen frames.
- Login linked to Home in Prototype mode; flow runs in Present mode.

## Screenshots

Add your screenshots to a `screenshots/` folder here and link them:

```markdown
![Step output](screenshots/step1.png)
```

## Result

Clickable Bus Ticket Booking prototype designed and navigation tested in Figma.

## Viva Questions

**1. What is a prototype?**  
Ans: An early working model used to understand and validate requirements.

**2. What is a Frame?**  
Ans: A fixed-size container/artboard for a screen.

**3. How are screens linked?**  
Ans: Prototype mode → drag connector to target frame → On Click → Navigate To.

**4. Which SDLC model uses prototyping?**  
Ans: Prototyping model and evolutionary/incremental models.

**5. Wireframe vs mock-up?**  
Ans: Wireframe = low-fidelity layout; mock-up = high-fidelity static design.

