# Experiment 26: Cloning a GitHub Repository and Editing Files Locally

**Course:** CSA10 – Software Engineering  |  **Tools:** Git / GitHub  |  **CO:** CO3

## Aim

Clone an existing repository and modify a file locally.

## Procedure

1. Copy the HTTPS URL of a public repo.
2. `git clone <repository_url>`; `cd` into it.
3. Open in VS Code, make a small edit, save.
4. `git status` shows `modified`.

## Code / Commands

```text
git clone <repository_url>
cd <repository_name>
code .
git status
git diff
```

## Expected Output

- `Cloning into ... done.`; `git status` shows `modified: README.md`.

## Screenshots

Implementation screenshots are listed below. Add your own tool screenshots to `screenshots/` too.

## Result

Repository cloned and a file modified locally.

## Viva Questions

**1. What does clone copy?**  
Ans: Files, branches and full history.

**2. `git remote -v`?**  
Ans: Lists remote URLs.

**3. Show changes?**  
Ans: `git diff`.

**4. HTTPS vs SSH?**  
Ans: Token vs key-pair authentication.

**5. Clone private repos?**  
Ans: Yes, with access and authentication.

## Implementation Screenshots

> Real terminal output captured from running these commands (see note under each).

**Clone, edit and verify changes**

![Clone, edit and verify changes](screenshots/git_run.png)

_Captured locally; the GitHub remote is simulated with a local bare repository (same git commands)._

