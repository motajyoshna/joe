# Experiment 22: Push and Pull Docker Images using Docker Hub

**Course:** CSA10 – Software Engineering  |  **Tools:** Docker Hub, Docker CLI  |  **CO:** CO3

## Aim

Build a static-site image, push it to Docker Hub, pull and run it on another machine.

## Procedure

1. Create `web-image` with `index.html` and `Dockerfile`; build `static-web`.
2. Create Docker Hub repo `static-web`; `docker login`.
3. Tag as `<user>/static-web:1.0` and `:latest`; push both.
4. On a second machine (or Play with Docker) pull and run on port 8080.
5. Open the site to verify.

## Code / Commands

```text
# Dockerfile
FROM nginx:alpine
COPY index.html /usr/share/nginx/html/index.html
EXPOSE 80

# Commands
docker build -t static-web .
docker login -u <dockerhub-username>
docker tag static-web <dockerhub-username>/static-web:1.0
docker tag static-web <dockerhub-username>/static-web:latest
docker push <dockerhub-username>/static-web:1.0
docker push <dockerhub-username>/static-web:latest

# On another machine
docker pull <dockerhub-username>/static-web:1.0
docker run -d --name web -p 8080:80 <dockerhub-username>/static-web:1.0
curl http://localhost:8080
```

## Expected Output

- Tags 1.0 and latest on Docker Hub; page 'Hello from Docker Hub!' served from pulled image.

## Screenshots

Add your screenshots to a `screenshots/` folder here and link them:

```markdown
![Step output](screenshots/step1.png)
```

## Result

Image pushed to Docker Hub then pulled and run successfully.

## Viva Questions

**1. Docker Hub?**  
Ans: Cloud registry for sharing images.

**2. Default tag?**  
Ans: latest.

**3. Why docker tag before push?**  
Ans: Name must include username/repository.

**4. Access token?**  
Ans: Revocable credential used instead of a password.

**5. Make repo private?**  
Ans: Repository Settings → Visibility → Private.

