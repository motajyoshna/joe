# Experiment 6: UML Class, Use Case and Activity Diagrams for an Online Food Delivery System

**Course:** CSA10 – Software Engineering  |  **Tools:** Umbrello / StarUML  |  **CO:** CO1

## Aim

Design Class, Use Case and Activity diagrams for an Online Food Delivery System.

## Procedure

1. Create project `Online Food Delivery System`.
2. Class diagram: Customer, Restaurant, Menu, FoodItem, Order, Payment, DeliveryAgent, Delivery with attributes, methods, association/aggregation/composition/inheritance.
3. Use case diagram: actors Customer, Restaurant, Delivery Agent, Administrator; use cases Browse Restaurants, View Menu, Place Order, Make Payment, Track Order, Manage Menu, Update Order Status, Accept Delivery Request, Update Delivery Status.
4. Activity diagram: browse → select items → place order → payment (decision) → restaurant confirms → assign agent → track → complete.
5. Verify all three diagrams, save project, export as image/PDF.

## Expected Output

- Class, Use Case and Activity diagrams exported.

## Screenshots

Add your screenshots to a `screenshots/` folder here and link them:

```markdown
![Step output](screenshots/step1.png)
```

## Result

Class, Use Case and Activity diagrams for the food delivery system designed and verified.

## Viva Questions

**1. What is UML?**  
Ans: Unified Modelling Language, a standard notation for modelling software.

**2. Aggregation vs composition?**  
Ans: Aggregation = weak whole-part; composition = strong, parts die with whole.

**3. What is an actor?**  
Ans: A role played by a user or external system.

**4. include vs extend?**  
Ans: include = mandatory reuse; extend = optional conditional behaviour.

**5. Fork node?**  
Ans: Splits one flow into concurrent flows.

