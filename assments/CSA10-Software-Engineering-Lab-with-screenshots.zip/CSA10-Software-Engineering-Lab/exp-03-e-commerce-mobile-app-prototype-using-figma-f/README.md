# Experiment 3: E-Commerce Mobile App Prototype using Figma for Stakeholder Feedback

**Course:** CSA10 – Software Engineering  |  **Tools:** Figma  |  **CO:** CO1

## Aim

Design an interactive E-Commerce mobile prototype so stakeholders with conflicting UI views can review it and give feedback.

## Procedure

1. Sign in to Figma → New Design File.
2. Create mobile frames (e.g. iPhone 14 Plus) for each screen.
3. Home: logo, search bar, categories, featured products (image, price, rating), bottom nav.
4. Product Details: image, name, description, price, ratings, Add to Cart / Buy Now.
5. Cart: items, quantity, price, total, Proceed to Checkout.
6. Checkout: address, payment method, order summary, Place Order.
7. Order Confirmation: message, order ID, delivery date, Continue Shopping.
8. Prototype tab: connect all screens Home → Confirmation.
9. Present, share link (can comment), collect feedback.
10. Update the design from feedback, save and capture screenshots.

## Expected Output

- Mobile frames for Home, Listing, Details, Cart, Checkout.
- Screens connected; prototype link shared; feedback recorded as comments.

## Screenshots

Add your screenshots to a `screenshots/` folder here and link them:

```markdown
![Step output](screenshots/step1.png)
```

## Result

Interactive E-Commerce prototype created and shared with stakeholders for feedback.

## Viva Questions

**1. Why is prototyping useful when stakeholders disagree?**  
Ans: It gives a testable visual so decisions rest on what users see.

**2. What is Auto Layout?**  
Ans: Automatic spacing/resizing of child elements, like CSS flexbox.

**3. What is a component?**  
Ans: Reusable element; changes to the main component update all instances.

**4. How to share a prototype?**  
Ans: Share → set link access (view/comment) → send link.

**5. Two usability principles?**  
Ans: Consistency and visible navigation / clear calls-to-action.

