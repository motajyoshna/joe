# Experiment 7: UML Diagrams for a College Security Management System

**Course:** CSA10 – Software Engineering  |  **Tools:** Umbrello / StarUML  |  **CO:** CO1

## Aim

Design Class, Use Case and Activity diagrams for an Online Security Management System that automates duty allocation, leave and salary.

## Procedure

1. Create project `Online Security Management System`.
2. Class diagram: SecurityPersonnel, DutySchedule, CampusLocation, Leave, Salary, Administrator, Attendance.
3. Use case diagram: actors Administrator, Security Personnel, Accounts Officer; use cases Login, Assign Duty, View Duty Schedule, Apply Leave, Approve Leave, Record Attendance, Update Duty Status, Calculate Salary, Generate Salary Report, Logout.
4. Activity diagram: login → assign/view duty → perform duty → leave (approval decision) → attendance → salary → report → logout.
5. Verify, save, export diagrams.

## Expected Output

- Three diagrams with attributes, methods, associations and workflow.

## Screenshots

Add your screenshots to a `screenshots/` folder here and link them:

```markdown
![Step output](screenshots/step1.png)
```

## Result

UML diagrams for the College Security Management System designed and verified.

## Viva Questions

**1. Multiplicity?**  
Ans: Number of instances that can participate in an association, e.g. 1..*.

**2. System boundary?**  
Ans: Rectangle separating use cases from external actors.

**3. Which diagram shows static structure?**  
Ans: Class diagram.

**4. Swimlane?**  
Ans: Partition grouping activities by responsible actor.

**5. Generalization?**  
Ans: Inheritance where child specialises parent.

