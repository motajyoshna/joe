# Experiment 27: Committing and Pushing Changes to GitHub

**Course:** CSA10 – Software Engineering  |  **Tools:** Git / GitHub  |  **CO:** CO4

## Aim

Stage, commit and push local modifications to GitHub.

## Procedure

1. Clone the repo and modify README.md.
2. `git status`; `git add README.md`; `git commit -m "Updated README"`.
3. `git push origin main`; verify README and commit history on GitHub.

## Code / Commands

```text
git status
git add README.md
git commit -m "Updated README"
git push origin main
```

## Expected Output

- `1 file changed`; branch ahead of origin/main by 1 commit until pushed; then up to date.

## Screenshots

Implementation screenshots are listed below. Add your own tool screenshots to `screenshots/` too.

## Result

Changes staged, committed and pushed to GitHub.

## Viva Questions

**1. Commit?**  
Ans: Snapshot of staged changes with metadata.

**2. Change last message?**  
Ans: `git commit --amend -m "new"` (before pushing).

**3. 'Ahead by 1 commit'?**  
Ans: One local commit not yet pushed.

**4. Stage all?**  
Ans: `git add .` or `git add -A`.

**5. HEAD?**  
Ans: Pointer to current branch's latest commit.

## Implementation Screenshots

> Real terminal output captured from running these commands (see note under each).

**Stage, commit and push (ahead by 1, then up to date)**

![Stage, commit and push (ahead by 1, then up to date)](screenshots/git_run.png)

_Captured locally; the GitHub remote is simulated with a local bare repository (same git commands)._

