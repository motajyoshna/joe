# Experiment 5: Lexicographically Smallest String by Swapping Two Characters using RAPTOR

**Course:** CSA10 – Software Engineering  |  **Tools:** RAPTOR  |  **CO:** CO1

## Aim

Draw and validate a flowchart that swaps all occurrences of two chosen characters (at most once) to get the lexicographically smallest string.

## Procedure

1. Read `str`, `ch1`, `ch2` using three Input symbols.
2. Assignments: `i ← 1`, `n ← Length_Of(str)`.
3. Loop while `i <= n`.
4. Selection: if `str[i] = ch1` replace with `ch2`; else if `str[i] = ch2` replace with `ch1`.
5. `i ← i + 1`, loop back; after loop Output the modified string.
6. Run and validate with sample input.

## Code / Commands

```text
Example: str = ccad
First char 'c' has smaller 'a' later -> swap c <-> a -> aacd
```

## Expected Output

- Input: `str = ccad, ch1 = c, ch2 = a`
- Output: `aacd`

## Screenshots

Implementation screenshots are listed below. Add your own tool screenshots to `screenshots/` too.

## Result

Flowchart for lexicographically smallest string drawn and validated.

## Viva Questions

**1. Lexicographic order?**  
Ans: Dictionary order, compared from the left.

**2. Why at most once?**  
Ans: Only one pair swap (all occurrences) is allowed.

**3. Access i-th char?**  
Ans: str[i]; indexing starts at 1 in RAPTOR.

**4. Time complexity?**  
Ans: O(n) for replacement (O(26n) including finding the pair).

**5. Symbol for if-else?**  
Ans: Selection.

## Implementation Screenshots

> Real terminal output captured from running these commands (see note under each).

**Swap characters output**

![Swap characters output](screenshots/5.png)

_Python equivalent of the RAPTOR loop (not the RAPTOR GUI). Output matches expected aacd._

