# Experiment 21: Containerizing a Python Flask To-Do Application using Docker

**Course:** CSA10 – Software Engineering  |  **Tools:** Docker, Flask  |  **CO:** CO5

## Aim

Containerize a Flask To-Do app, test it in the container and push the image to Docker Hub.

## Procedure

1. Create `todo-app` with `app.py`, `templates/index.html`, `requirements.txt`, `Dockerfile`, `.dockerignore`.
2. `docker build -t todo-app:1.0 .`
3. `docker run -d --name todo -p 5000:5000 todo-app:1.0`; open http://localhost:5000.
4. Add, complete, delete tasks; test `/api/tasks`; check logs.
5. Tag and push to Docker Hub; clean up.

## Code / Commands

```text
# app.py
from flask import Flask, render_template, request, redirect, url_for, jsonify
app = Flask(__name__)
tasks = []

@app.route("/")
def index():
    return render_template("index.html", tasks=tasks)

@app.route("/add", methods=["POST"])
def add():
    title = request.form.get("task", "").strip()
    if title:
        tasks.append({"id": len(tasks) + 1, "title": title, "done": False})
    return redirect(url_for("index"))

@app.route("/done/<int:task_id>")
def done(task_id):
    for t in tasks:
        if t["id"] == task_id:
            t["done"] = True
    return redirect(url_for("index"))

@app.route("/delete/<int:task_id>")
def delete(task_id):
    global tasks
    tasks = [t for t in tasks if t["id"] != task_id]
    return redirect(url_for("index"))

@app.route("/api/tasks")
def api_tasks():
    return jsonify(tasks)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

# Dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
EXPOSE 5000
CMD ["python", "app.py"]

# Commands
curl http://localhost:5000/api/tasks
docker logs todo
docker tag todo-app:1.0 <dockerhub-username>/todo-app:1.0
docker push <dockerhub-username>/todo-app:1.0
docker stop todo && docker rm todo
```

## Expected Output

- To-Do app works in the container; image visible on Docker Hub.

## Screenshots

Implementation screenshots are listed below. Add your own tool screenshots to `screenshots/` too.

## Result

Flask To-Do app containerized, tested and pushed to Docker Hub.

## Viva Questions

**1. Why copy requirements.txt first?**  
Ans: Layer caching: reinstall only when dependencies change.

**2. docker exec -it?**  
Ans: Runs an interactive command in a running container.

**3. View logs?**  
Ans: `docker logs <container>`.

**4. .dockerignore?**  
Ans: Excludes paths from the build context.

**5. Why python:3.11-slim?**  
Ans: Smaller image, faster builds, smaller attack surface.

## Implementation Screenshots

> Real terminal output captured from running these commands (see note under each).

**To-Do app: add, done, delete and JSON endpoint**

![To-Do app: add, done, delete and JSON endpoint](screenshots/local_run.png)

_Flask app tested locally with curl. docker build/run/push were not run here._

