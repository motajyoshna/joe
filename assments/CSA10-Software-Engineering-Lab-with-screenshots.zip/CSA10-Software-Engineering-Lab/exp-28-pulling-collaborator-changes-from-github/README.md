# Experiment 28: Pulling Collaborator Changes from GitHub

**Course:** CSA10 – Software Engineering  |  **Tools:** Git / GitHub  |  **CO:** CO4

## Aim

Pull a collaborator's pushed changes into the local repository.

## Procedure

1. Clone the repo.
2. Collaborator edits README, commits and pushes to main.
3. Check `git status` (local lacks the change).
4. `git pull origin main`.
5. Open the file and confirm; `git status` shows up to date.

## Code / Commands

```text
git clone <repository_url>
cd <repository_name>
git pull origin main
git status
```

## Expected Output

- `Fast-forward`, `1 file changed`; collaborator's text appears locally.

## Screenshots

Implementation screenshots are listed below. Add your own tool screenshots to `screenshots/` too.

## Result

Collaborator changes pulled and verified.

## Viva Questions

**1. pull vs fetch?**  
Ans: fetch downloads; pull downloads and merges.

**2. Fast-forward?**  
Ans: Pointer moves ahead when no local commits diverge.

**3. Add collaborator?**  
Ans: Settings → Collaborators → Add people.

**4. Same line changed by both?**  
Ans: Merge conflict to resolve manually.

**5. `git pull --rebase`?**  
Ans: Replays local commits on top of fetched ones.

## Implementation Screenshots

> Real terminal output captured from running these commands (see note under each).

**Pull collaborator changes (Fast-forward)**

![Pull collaborator changes (Fast-forward)](screenshots/git_run.png)

_Captured locally; the GitHub remote is simulated with a local bare repository (same git commands)._

