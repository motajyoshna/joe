# CSA10 – Software Engineering Laboratory

Saveetha School of Engineering, SIMATS – Department of Computer Science and Engineering

Documentation for all 30 lab experiments. Each folder has a `README.md` with Aim, Procedure, Code/Commands, Expected Output, Result and Viva Questions, plus a `screenshots/` folder for your output images.

## Experiments

| No. | Experiment | Tools | CO |
|---|---|---|---|
| 1 | [Kanban Board for Task Visualization using Jira](./exp-01-kanban-board-for-task-visualization-using-jir) | Jira / Trello | CO1 |
| 2 | [Prototype of a Bus Ticket Booking System using Figma](./exp-02-prototype-of-a-bus-ticket-booking-system-usin) | Figma | CO1 |
| 3 | [E-Commerce Mobile App Prototype using Figma for Stakeholder Feedback](./exp-03-e-commerce-mobile-app-prototype-using-figma-f) | Figma | CO1 |
| 4 | [Flowchart to Find the Length of a String using RAPTOR](./exp-04-flowchart-to-find-the-length-of-a-string-usin) | RAPTOR | CO1 |
| 5 | [Lexicographically Smallest String by Swapping Two Characters using RAPTOR](./exp-05-lexicographically-smallest-string-by-swapping) | RAPTOR | CO1 |
| 6 | [UML Class, Use Case and Activity Diagrams for an Online Food Delivery System](./exp-06-uml-class-use-case-and-activity-diagrams-for) | Umbrello / StarUML | CO1 |
| 7 | [UML Diagrams for a College Security Management System](./exp-07-uml-diagrams-for-a-college-security-managemen) | Umbrello / StarUML | CO1 |
| 8 | [Cyclomatic Complexity of a Flow Graph](./exp-08-cyclomatic-complexity-of-a-flow-graph) | RAPTOR / calculator | CO1 |
| 9 | [Creating a Scrum Project with Backlog and Sprint in Jira](./exp-09-creating-a-scrum-project-with-backlog-and-spr) | Jira | CO2 |
| 10 | [MoSCoW Prioritization of Library Management System Requirements](./exp-10-moscow-prioritization-of-library-management-s) | Google Sheets / Excel | CO2 |
| 11 | [Linking Jira Issues with Confluence for Progress Tracking](./exp-11-linking-jira-issues-with-confluence-for-progr) | Jira & Confluence | CO2 |
| 12 | [Prioritizing Task Management System Requirements using MoSCoW and Kano in Jira](./exp-12-prioritizing-task-management-system-requireme) | Jira | CO2 |
| 13 | [Prioritizing Online Learning Platform Requirements using MoSCoW and Kano in Jira](./exp-13-prioritizing-online-learning-platform-require) | Jira | CO2 |
| 14 | [Fork-and-Pull-Request Collaboration Workflow using Git and GitHub](./exp-14-fork-and-pull-request-collaboration-workflow) | Git / GitHub | CO3 |
| 15 | [Working with Git Branches and Resolving Merge Conflicts](./exp-15-working-with-git-branches-and-resolving-merge) | Git / GitHub | CO3 |
| 16 | [Static Website Containerized and Served with Docker and Nginx](./exp-16-static-website-containerized-and-served-with) | Docker | CO3 |
| 17 | [Flask API Containerized with Docker, Pushed to Docker Hub and Deployed on Kubernetes](./exp-17-flask-api-containerized-with-docker-pushed-to) | Docker & Kubernetes | CO3 |
| 18 | [CI/CD Pipeline with Jenkins for a Containerized Application](./exp-18-ci-cd-pipeline-with-jenkins-for-a-containeriz) | Jenkins, Docker | CO4 |
| 19 | [Continuous Deployment of a Dockerized Application using GitHub Actions](./exp-19-continuous-deployment-of-a-dockerized-applica) | GitHub Actions, Docker | CO5 |
| 20 | [Team Project Repository with Branches, Pull Requests and README Documentation](./exp-20-team-project-repository-with-branches-pull-re) | Git / GitHub | CO3 |
| 21 | [Containerizing a Python Flask To-Do Application using Docker](./exp-21-containerizing-a-python-flask-to-do-applicati) | Docker, Flask | CO5 |
| 22 | [Push and Pull Docker Images using Docker Hub](./exp-22-push-and-pull-docker-images-using-docker-hub) | Docker Hub, Docker CLI | CO3 |
| 23 | [Multi-Container Application (Frontend, Backend, Database) on Kubernetes with Scaling](./exp-23-multi-container-application-frontend-backend) | Docker, Kubernetes | CO3 |
| 24 | [CI/CD Pipeline for a Flask Application using GitHub Actions with Cloud Deployment](./exp-24-ci-cd-pipeline-for-a-flask-application-using) | GitHub Actions, Docker | CO3 |
| 25 | [Creating a GitHub Repository and Pushing a README File](./exp-25-creating-a-github-repository-and-pushing-a-re) | Git / GitHub | CO3 |
| 26 | [Cloning a GitHub Repository and Editing Files Locally](./exp-26-cloning-a-github-repository-and-editing-files) | Git / GitHub | CO3 |
| 27 | [Committing and Pushing Changes to GitHub](./exp-27-committing-and-pushing-changes-to-github) | Git / GitHub | CO4 |
| 28 | [Pulling Collaborator Changes from GitHub](./exp-28-pulling-collaborator-changes-from-github) | Git / GitHub | CO4 |
| 29 | [Feature Branch (feature-login) and Pull Request](./exp-29-feature-branch-feature-login-and-pull-request) | Git / GitHub | CO4 |
| 30 | [Forking, Feature Branch and Pull Request to the Original Repository](./exp-30-forking-feature-branch-and-pull-request-to-th) | Git / GitHub | CO4 |

## How to publish this repository

```bash
cd CSA10-Software-Engineering-Lab
git init
git add .
git commit -m "Add lab experiment documentation"
git branch -M main
git remote add origin https://github.com/<your-username>/<register-no>-se-lab.git
git push -u origin main
```

> Tip: use your register number in the repository name and never commit passwords or tokens.

## Implementation screenshots status

Real terminal captures are included for the experiments marked ✅. The rest need tools that can't be run in this sandbox, so take those screenshots yourself and put them in each folder's `screenshots/` directory.

| Exp | Status |
|---|---|
| 1 | 📸 take your own (needs GUI tool / cloud / Docker Hub / cluster) |
| 2 | 📸 take your own (needs GUI tool / cloud / Docker Hub / cluster) |
| 3 | 📸 take your own (needs GUI tool / cloud / Docker Hub / cluster) |
| 4 | ✅ terminal capture included |
| 5 | ✅ terminal capture included |
| 6 | 📸 take your own (needs GUI tool / cloud / Docker Hub / cluster) |
| 7 | 📸 take your own (needs GUI tool / cloud / Docker Hub / cluster) |
| 8 | ✅ terminal capture included |
| 9 | 📸 take your own (needs GUI tool / cloud / Docker Hub / cluster) |
| 10 | 📸 take your own (needs GUI tool / cloud / Docker Hub / cluster) |
| 11 | 📸 take your own (needs GUI tool / cloud / Docker Hub / cluster) |
| 12 | 📸 take your own (needs GUI tool / cloud / Docker Hub / cluster) |
| 13 | 📸 take your own (needs GUI tool / cloud / Docker Hub / cluster) |
| 14 | 📸 take your own (needs GUI tool / cloud / Docker Hub / cluster) |
| 15 | ✅ terminal capture included |
| 16 | 📸 take your own (needs GUI tool / cloud / Docker Hub / cluster) |
| 17 | ✅ terminal capture included |
| 18 | ✅ terminal capture included |
| 19 | 📸 take your own (needs GUI tool / cloud / Docker Hub / cluster) |
| 20 | 📸 take your own (needs GUI tool / cloud / Docker Hub / cluster) |
| 21 | ✅ terminal capture included |
| 22 | 📸 take your own (needs GUI tool / cloud / Docker Hub / cluster) |
| 23 | 📸 take your own (needs GUI tool / cloud / Docker Hub / cluster) |
| 24 | ✅ terminal capture included |
| 25 | ✅ terminal capture included |
| 26 | ✅ terminal capture included |
| 27 | ✅ terminal capture included |
| 28 | ✅ terminal capture included |
| 29 | ✅ terminal capture included |
| 30 | ✅ terminal capture included |
